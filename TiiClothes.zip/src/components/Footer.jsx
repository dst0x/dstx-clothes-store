import { useState } from "react";
import { ECOMMERCE_PLATFORMS } from "./data";
import Ticker from "./Ticker";

const NAV_LINKS = {
  Koleksi: ["Jacket", "Kemeja", "Outer", "Totebag", "Jeans"],
  Informasi: ["Tentang Kami", "Blog", "FAQ", "Kontak"],
  Kebijakan: ["Syarat & Ketentuan", "Privasi", "Retur & Refund", "Cookie"],
};

export default function Footer() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (email) { setSent(true); setEmail(""); }
  };

  return (
    <footer className="bg-[#0C0C0C] text-white">

      {/* ── Dark Ticker ── */}
      <Ticker dark />

      {/* ── Main Footer Body ── */}
      <div className="max-w-7xl mx-auto px-8">

        {/* ── TOP SECTION: Brand + Newsletter ── */}
        <div className="py-20 grid grid-cols-12 gap-12 border-b border-white/[0.06]">

          {/* Brand */}
          <div className="col-span-12 md:col-span-5">
            <p className="text-2xl font-black tracking-[0.2em] uppercase text-white mb-1">
              TiiClothes
            </p>
            <p className="text-[10px] tracking-[0.25em] text-white/30 uppercase mb-8">
              Yogyakarta Fashion House · Est. 2020
            </p>
            <p className="text-sm text-white/50 leading-relaxed max-w-xs">
              Fashion lokal berkualitas premium dari jantung kota Yogyakarta.
              Dirancang untuk mereka yang menghargai gaya, kenyamanan, dan identitas.
            </p>
          </div>

          {/* Newsletter */}
          <div className="col-span-12 md:col-span-4 md:col-start-8 flex flex-col justify-between">
            <div>
              <p className="text-[10px] tracking-[0.25em] text-white/30 uppercase mb-4">Newsletter</p>
              <p className="text-sm text-white/60 leading-relaxed mb-6">
                Dapatkan info drop terbaru dan penawaran eksklusif langsung ke emailmu.
              </p>
            </div>

            {sent ? (
              <p className="text-xs text-[#FF4D00] tracking-widest uppercase">
                ✦ Terima kasih sudah bergabung!
              </p>
            ) : (
              <form onSubmit={handleSubmit}>
                <div className="flex items-center border-b border-white/20 pb-3 gap-3 group focus-within:border-white/60 transition-colors duration-300">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="email@kamu.com"
                    className="bg-transparent text-sm text-white placeholder-white/20 outline-none flex-1"
                    required
                  />
                  <button
                    type="submit"
                    className="text-white/40 hover:text-white transition-colors duration-200 text-sm"
                  >
                    →
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>

        {/* ── MIDDLE SECTION: Links + Contact + E-Commerce ── */}
        <div className="py-16 grid grid-cols-12 gap-10 border-b border-white/[0.06]">

          {/* Nav Links */}
          <div className="col-span-12 md:col-span-6 grid grid-cols-3 gap-8">
            {Object.entries(NAV_LINKS).map(([section, links]) => (
              <div key={section}>
                <p className="text-[10px] tracking-[0.25em] text-white/30 uppercase mb-5">
                  {section}
                </p>
                <ul className="space-y-3">
                  {links.map((link) => (
                    <li key={link}>
                      <a
                        href="#"
                        className="text-xs text-white/50 hover:text-white transition-colors duration-200 leading-relaxed"
                      >
                        {link}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          {/* Contact */}
          <div className="col-span-12 md:col-span-3">
            <p className="text-[10px] tracking-[0.25em] text-white/30 uppercase mb-5">Kontak</p>
            <div className="space-y-4">
              <div>
                <p className="text-[10px] text-white/25 uppercase tracking-widest mb-1">Lokasi</p>
                <p className="text-xs text-white/60 leading-relaxed">
                  Jl. Malioboro No. 88<br />
                  Yogyakarta 55271
                </p>
              </div>
              <div>
                <p className="text-[10px] text-white/25 uppercase tracking-widest mb-1">Email</p>
                <a href="mailto:hello@tiiclothes.id" className="text-xs text-white/60 hover:text-white transition-colors">
                  hello@tiiclothes.id
                </a>
              </div>
              <div>
                <p className="text-[10px] text-white/25 uppercase tracking-widest mb-1">WhatsApp</p>
                <a
                  href="https://wa.me/6281234567890"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs text-white/60 hover:text-white transition-colors"
                >
                  +62 812-3456-7890
                </a>
              </div>
              <div>
                <p className="text-[10px] text-white/25 uppercase tracking-widest mb-1">Jam Buka</p>
                <p className="text-xs text-white/60">08.00 – 22.00 WIB</p>
              </div>
            </div>
          </div>

          {/* E-Commerce */}
          <div className="col-span-12 md:col-span-3">
            <p className="text-[10px] tracking-[0.25em] text-white/30 uppercase mb-5">Beli Online</p>
            <div className="space-y-3">
              {ECOMMERCE_PLATFORMS.map((p) => (
                <a
                  key={p.name}
                  href={p.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-between group py-2 border-b border-white/[0.04] hover:border-white/20 transition-colors duration-200"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-base">{p.icon}</span>
                    <div>
                      <p className="text-xs text-white/70 group-hover:text-white transition-colors font-medium">
                        {p.name}
                      </p>
                      <p className="text-[10px] text-white/30">{p.desc}</p>
                    </div>
                  </div>
                  <span className="text-white/20 group-hover:text-white/60 transition-colors text-xs">→</span>
                </a>
              ))}
            </div>

            {/* Social */}
            <div className="mt-8">
              <p className="text-[10px] tracking-[0.25em] text-white/30 uppercase mb-4">Sosial</p>
              <div className="flex gap-2">
                {[
                  { label: "IG", href: "https://instagram.com/tiiclothes" },
                  { label: "TK", href: "https://tiktok.com/@tiiclothes" },
                  { label: "FB", href: "https://facebook.com/tiiclothes" },
                  { label: "YT", href: "https://youtube.com/@tiiclothes" },
                ].map(({ label, href }) => (
                  <a
                    key={label}
                    href={href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-9 h-9 rounded-full border border-white/10 flex items-center justify-center text-[10px] font-bold text-white/30 hover:border-white/40 hover:text-white/70 transition-all duration-200"
                  >
                    {label}
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* ── BOTTOM BAR ── */}
        <div className="py-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-[10px] text-white/20 tracking-widest">
            © 2026 TiiClothes. All rights reserved. Made with ✦ in Yogyakarta.
          </p>
          <div className="flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-[#FF4D00] animate-pulse" />
            <p className="text-[10px] text-white/20 tracking-widest">
              Yogyakarta Fashion House · Est. 2020
            </p>
          </div>
        </div>

      </div>
    </footer>
  );
}
