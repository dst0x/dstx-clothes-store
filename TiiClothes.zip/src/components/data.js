// ─── DATA ─────────────────────────────────────────────────────────────────────

export const CATEGORIES = [
  { id: "01", name: "Shirt", count: 174 },
  { id: "02", name: "Jacket", count: 361, active: true },
  { id: "03", name: "Jeans", count: 368 },
  { id: "04", name: "Outer", count: 117 },
  { id: "05", name: "Shoes", count: 78 },
];

export const TESTIMONIALS = [
  {
    id: 1,
    name: "Emma Williams",
    title: "Fashion Stylist",
    quote:
      "Everything is absolutely perfect! From the fabric quality to the flawless fit every piece feels premium. This brand has completely transformed my wardrobe.",
    rating: 5,
    reviews: 49,
    image: "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=800&q=90",
  },
  {
    id: 2,
    name: "Marcus Chen",
    title: "Creative Director",
    quote:
      "TiiClothes has redefined what urban fashion means to me. The cuts are precise, the materials last, and every drop feels intentional. Genuinely impressive.",
    rating: 5,
    reviews: 37,
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&q=90",
  },
  {
    id: 3,
    name: "Sofia Reyes",
    title: "Content Creator",
    quote:
      "I've been wearing TiiClothes exclusively for six months. The quality speaks for itself — these pieces hold up and still look brand new every season.",
    rating: 5,
    reviews: 62,
    image: "https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?w=800&q=90",
  },
];

export const FEATURED_PRODUCTS = [
  {
    id: 1,
    title: "©TiiClothes — going distance 2026",
    price: 120,
    discount: null,
    image: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=1200&q=90",
    label: "Where Elegance Meets Sustainability — Luxury Made Accessible",
  },
  {
    id: 2,
    title: "©TiiClothes — just do it 2026",
    price: 220,
    discount: 45,
    image: "https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=1200&q=90",
    label: null,
  },
];

export const GALLERY_ITEMS = [
  { id: 1, image: "https://images.unsplash.com/photo-1516826957135-700dedea698c?w=1200&q=90", label: null },
  { id: 2, image: "https://images.unsplash.com/photo-1539109136881-3be0616acf4b?w=1200&q=90", label: null },
  { id: 3, image: "https://images.unsplash.com/photo-1483985988355-763728e1935b?w=1200&q=90", label: "[Wear the Moment]", active: true },
  { id: 4, image: "https://images.unsplash.com/photo-1509631179647-0177331693ae?w=1200&q=90", label: null },
  { id: 5, image: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=1200&q=90", label: null },
];

export const COLLECTIONS = [
  {
    id: 1,
    name: "Statement Pieces 2025",
    desc: "Your go-to wardrobe staples, crafted for comfort and effortless style.",
    active: true,
    image: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=800&q=90",
  },
  { id: 2, name: "Everyday Essentials 2026", desc: "Simple, clean, and built to last every day of the week." },
  { id: 3, name: "Timeless Classics 2026", desc: "Iconic silhouettes that never go out of style." },
  { id: 4, name: "Seasonal Collections 2025", desc: "Limited drops curated for the season ahead." },
];

export const TICKER_ITEMS = [
  "STYLING", "CRAFTED STORIES", "PREMIUM MATERIALS", "PREMIUM FABRICS",
  "TIMELESS CUTS", "URBAN INFLUENCE", "SMART STYLING", "MADE IN JOGJA",
];

export const ECOMMERCE_PLATFORMS = [
  {
    name: "Shopee",
    url: "https://shopee.co.id/tiiclothes",
    color: "#EE4D2D",
    icon: "🛍️",
    desc: "Gratis ongkir & cashback",
  },
  {
    name: "Tokopedia",
    url: "https://tokopedia.com/tiiclothes",
    color: "#00AA5B",
    icon: "🟢",
    desc: "Official store tersedia",
  },
  {
    name: "Lazada",
    url: "https://lazada.co.id/shop/tiiclothes",
    color: "#0F146D",
    icon: "🔵",
    desc: "Flash sale setiap hari",
  },
  {
    name: "TikTok Shop",
    url: "https://tiktok.com/@tiiclothes",
    color: "#000000",
    icon: "🎵",
    desc: "Live shopping setiap malam",
  },
];
