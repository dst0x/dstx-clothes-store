import { FEATURED_PRODUCTS } from "./data";
import { OrangePlus, ClipImage, SectionLabel } from "./utils";
import Ticker from "./Ticker";

export default function FeaturedSection() {
  return (
    <section className="bg-white py-32 px-8 overflow-hidden">
      <div className="max-w-7xl mx-auto">
        
        {/* Section Label */}
        <div className="flex justify-center mb-16">
          <SectionLabel>New Drop — 2026 Collection</SectionLabel>
        </div>

        {/* ── HERO-STYLE COMPOSITION ── */}
        <div className="flex flex-col md:flex-row items-center justify-center relative mb-40">
          
          {/* Left Text */}
          <div className="z-10 md:-mr-24 text-center md:text-right mb-10 md:mb-0">
            <h2 className="text-[10vw] md:text-[7vw] font-black leading-[0.82] tracking-tighter text-black uppercase">
              All —<br />
              <span className="md:mr-4">about</span>
            </h2>
            <div className="flex flex-col items-center md:items-end mt-6">
              <p className="text-[10px] tracking-[0.4em] text-gray-300 uppercase">Crafted Excellence</p>
              <div className="w-12 h-px bg-[#FF4D00] mt-2" />
            </div>
          </div>

          {/* Central Image Showcase */}
          <div className="relative w-full max-w-sm z-0">
            {/* Decorative Elements */}
            <div className="absolute -top-8 -right-8 z-20 animate-pulse">
              <OrangePlus size={56} />
            </div>
            
            <div className="relative group">
              <div className="absolute -inset-4 border border-gray-100 -z-10 group-hover:scale-105 transition-transform duration-700" />
              <img
                src={FEATURED_PRODUCTS[0].image}
                alt="Featured Jacket"
                className="w-full aspect-[3/4] object-cover shadow-[0_30px_60px_-15px_rgba(0,0,0,0.3)] transition-transform duration-700 group-hover:scale-[1.02]"
              />
              {/* Corner accent */}
              <div className="absolute bottom-0 right-0 w-24 h-24 bg-white flex items-center justify-center">
                 <p className="text-xl font-black text-black">Rp 1.2M</p>
              </div>
            </div>

            {/* Floating Caption Box */}
            <div className="absolute -bottom-16 -left-12 bg-[#0A0A0A] text-white p-8 shadow-2xl max-w-[240px] hidden lg:block">
              <span className="text-[#FF4D00] text-xl absolute -top-3 -left-3">✦</span>
              <p className="text-[9px] tracking-[0.3em] uppercase text-white/30 mb-4">The Statement</p>
              <p className="text-sm font-light italic leading-relaxed text-white/80">
                "{FEATURED_PRODUCTS[0].label}"
              </p>
            </div>
          </div>

          {/* Right Text */}
          <div className="z-10 md:-ml-24 text-center md:text-left mt-10 md:mt-0">
            <h2 className="text-[10vw] md:text-[7vw] font-black leading-[0.82] tracking-tighter text-[#FF4D00] uppercase">
              moments<br />
              <span className="md:ml-4 text-black">©26</span>
            </h2>
            <div className="flex flex-col items-center md:items-start mt-6">
              <p className="text-[10px] tracking-[0.4em] text-gray-300 uppercase">Yogyakarta · Limited</p>
              <button className="mt-8 group flex items-center gap-4">
                <span className="text-[10px] font-bold tracking-[0.3em] uppercase text-black group-hover:text-[#FF4D00] transition-colors">Lihat Semua</span>
                <div className="w-10 h-10 rounded-full border border-black flex items-center justify-center group-hover:bg-[#FF4D00] group-hover:border-[#FF4D00] transition-all duration-300">
                  <span className="text-black group-hover:text-white group-hover:translate-x-1 transition-all">→</span>
                </div>
              </button>
            </div>
          </div>
        </div>

        {/* ── SECONDARY PRODUCT GRID ── */}
        <div className="grid grid-cols-12 gap-12 items-start pt-20 border-t border-gray-50">
          
          {/* Left Column: Niche Badge */}
          <div className="col-span-12 lg:col-span-3">
             <div className="bg-[#F9F9F7] p-10 border-l-4 border-[#FF4D00]">
                <p className="text-[10px] font-black tracking-[0.3em] uppercase text-black mb-4">Premium Quality</p>
                <p className="text-xs text-gray-500 leading-relaxed mb-6">
                  Setiap jahitan diproses dengan ketelitian tinggi oleh pengrajin lokal terbaik di Yogyakarta.
                </p>
                <div className="flex gap-1">
                  {[1,2,3].map(i => <div key={i} className="w-1.5 h-1.5 rounded-full bg-[#FF4D00]" />)}
                </div>
             </div>
          </div>

          {/* Center Column: Secondary Product */}
          <div className="col-span-12 lg:col-span-6 flex flex-col items-center">
            <div className="relative w-full group">
              <ClipImage
                src={FEATURED_PRODUCTS[1].image}
                alt={FEATURED_PRODUCTS[1].title}
                className="w-full h-[400px]"
              />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-center justify-center">
                <button className="bg-white text-black text-[10px] font-bold tracking-widest px-8 py-4 rounded-full uppercase hover:bg-[#FF4D00] hover:text-white transition-all">
                  Quick View
                </button>
              </div>
            </div>
            <div className="w-full flex justify-between items-center mt-6">
              <div>
                <p className="text-[10px] tracking-widest text-gray-400 uppercase">{FEATURED_PRODUCTS[1].title}</p>
                <p className="text-lg font-black text-black">Modern Outerwear</p>
              </div>
              <div className="text-right">
                <span className="text-xs text-[#FF4D00] font-bold">-45% OFF</span>
                <p className="text-2xl font-black text-black">Rp 2.2M</p>
              </div>
            </div>
          </div>

          {/* Right Column: Decorative Detail */}
          <div className="col-span-12 lg:col-span-3 lg:pt-20">
            <div className="text-right">
              <p className="text-xs text-gray-400 italic mb-6">
                "Fashion is the armor to survive the reality of everyday life."
              </p>
              <div className="inline-block relative">
                <img 
                  src="https://images.unsplash.com/photo-1516826957135-700dedea698c?w=400&q=90" 
                  className="w-32 h-32 object-cover grayscale hover:grayscale-0 transition-all duration-700" 
                  alt="Detail"
                />
                <div className="absolute -bottom-4 -left-4 w-12 h-12 bg-[#FF4D00] flex items-center justify-center text-white font-black">
                  ©26
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ── FOOTER TICKER ── */}
      <div className="mt-32 -mx-8">
        <Ticker />
      </div>
    </section>
  );
}
